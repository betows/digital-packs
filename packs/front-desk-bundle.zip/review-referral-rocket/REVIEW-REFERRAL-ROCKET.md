# Review & Referral Rocket — SOP (1 page)

**SKU:** `review-referral-rocket` · **US$29**  
Ask for a review (and later a referral) after a good visit. Templates only — you send them yourself.

**Who it’s for:** dental, salon, HVAC/plumbing, and similar local SMBs.  
**What it’s not:** software, Google API access, review bots, or auto-posting. No invented “X% more reviews” claims — results depend on how consistently you ask.

Replace `{{business}}`, `{{first}}`, `{{review_link}}`, `{{phone}}`, `{{staff}}`, `{{booking_url}}` before sending.

---

## When to ask

1. **Only after a good visit.** Patient/client smiled, thanked you, paid without friction, or said something positive out loud. Skip bad or lukewarm visits.
2. **Same day is best (Day 0).** In person at checkout, or SMS/email within a few hours while the visit is fresh.
3. **One ask, one channel first.** In-person QR *or* SMS *or* email — don’t hit all three the same hour.
4. **Day 3 soft bump** only if they never replied and never left a review. Skip if they said no, STOP, or already reviewed.
5. **Referral ask comes later.** After they’ve left a review *or* after 1–2 more happy visits — not in the same message as the first review ask (feels pushy).

## How to run it

1. Checkout / wrap-up: use `in-person-qr-script.md` if they’re standing there. Hand them the QR (phone camera → your Google review link).
2. If they leave without scanning: send SMS Day 0 from `sms-day0-day3.md` for your vertical, *or* `email-review-ask.md`.
3. Log the row in `tracker-template.csv` the same day (`asked?` = yes).
4. Day 3: if no review and no reply, send the Day 3 SMS *or* the soft email bump — pick one.
5. When a review lands: mark `reviewed?` = yes. Thank them once (short SMS/email is fine). Don’t keep asking.
6. Referral: use `email-referral-ask.md` (or a short SMS you adapt) after the review, or after another good visit. Mark `referred?` when someone new books because of them.

## Rules that keep you honest

- Use your real business number and name.  
- Honor **STOP**, **unsubscribe**, or “no thanks” the same day — no more review/referral texts to that person.  
- Link only to your official review page (Google Business Profile review link, or the platform you actually use). Don’t gate service on leaving a review.  
- Don’t offer money or free work in exchange for a *positive* review if that violates the platform’s rules — keep incentives (if any) legal and disclosed. This pack assumes a plain ask, no paid reviews.  
- Don’t write the review for them. Don’t pressure staff to invent reviews.

**Speed rule:** a plain “we’d love a review if we earned it” at the chair beats a perfect email next week.
