# Review & Referral Rocket Pack

**SKU:** `review-referral-rocket`  
**Price:** US$29 (one-time)

Templates and a one-page SOP so a local business can ask for Google/reviews and referrals after a good visit — by SMS, email, or in person. Paste into your own phone, email, or print a QR card. Nothing runs in the cloud for you.

## What's included

| File | What it is |
|------|------------|
| `REVIEW-REFERRAL-ROCKET.md` | 1-page SOP (when to ask, when to stop) |
| `sms-day0-day3.md` | SMS for dental, salon, HVAC (Day 0 review ask + Day 3 soft bump + opt-out) |
| `email-review-ask.md` | Email templates to ask for a review (EN) |
| `email-referral-ask.md` | Email templates to ask for a referral (EN) |
| `in-person-qr-script.md` | 30-second front-desk / chair-side script + QR tip |
| `tracker-template.csv` | Simple log: date, channel, asked?, reviewed?, referred?, notes |

## Who it's for

US local SMBs — dental, salon/beauty, HVAC/plumbing — where the owner or front desk can send a short text or email after a happy visit.

## What this is not

- Not a SaaS, app, or dashboard  
- Not Google API / Google Business Profile automation  
- Not auto-posting, buying, or fabricating reviews  
- Not an SMS/email sender — you copy-paste into your own tools  
- Not legal advice on review solicitation (follow your state rules and Google’s policies)

## How to use (60-second start)

1. Read `REVIEW-REFERRAL-ROCKET.md`.  
2. Replace `{{business}}`, `{{first}}`, `{{review_link}}`, `{{phone}}`, etc.  
3. Ask only after a clearly good visit.  
4. Log each ask in `tracker-template.csv`.  
5. Honor STOP / unsubscribe the same day.

Replace placeholders before you send. Keep the ask short. One channel at a time is enough.
