# Email — Review ask (EN)

Use after a clearly good visit. One email is enough for most customers; use the soft bump only if they never replied and didn’t leave a review.

**Placeholders:** `{{business}}` · `{{first}}` · `{{review_link}}` · `{{phone}}` · `{{staff}}` · `{{service}}`

Works for dental, salon, and HVAC — fill `{{service}}` (e.g. cleaning, cut & color, AC repair) or delete that phrase.

---

## Day 0 — review ask

**Subject:** Thanks for visiting {{business}}

Hi {{first}},

Thanks for coming in today for your {{service}}. We’re glad we could help.

If we earned it, a short Google review helps other people in town find us:

{{review_link}}

No pressure either way — and thank you again.

— {{staff}}  
{{business}}  
{{phone}}

---

## Day 0 — shorter version

**Subject:** Quick favor if we earned it — {{business}}

Hi {{first}},

Appreciate your visit. If you’re happy with {{business}}, would you leave a quick Google review?

{{review_link}}

Thanks either way.

— {{business}} · {{phone}}

---

## Day 3 — soft bump (optional)

**Subject:** Re: thanks for visiting {{business}}

Hi {{first}},

Just a short follow-up in case my last note got buried. If you have 30 seconds and we earned a review, here’s the link again:

{{review_link}}

If not, no worries — we won’t keep emailing about this.

— {{business}}  
{{phone}}

---

## Thank-you after they review

**Subject:** We saw your review — thank you

Hi {{first}},

We saw your Google review — thank you. Notes like yours help the team and help neighbors choose with confidence.

Glad we could help. If you need us again: {{phone}}

— {{business}}

---

## Compliance note

Include your normal unsubscribe footer. Don’t send review-ask emails to people who already unsubscribed from marketing, unless this is a follow-up you’re allowed to send under your own policy.
