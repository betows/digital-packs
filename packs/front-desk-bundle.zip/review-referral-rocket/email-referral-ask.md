# Email — Referral ask (EN)

Send **after** they’ve had a good experience — ideally after they left a review, or after a second happy visit. Don’t combine the first review ask and a referral ask in one message.

**Placeholders:** `{{business}}` · `{{first}}` · `{{phone}}` · `{{booking_url}}` · `{{staff}}`

Fine for dental, salon, and HVAC as written; tweak the examples in brackets if you want vertical-specific language.

---

## Referral ask — standard

**Subject:** Know someone who needs {{business}}?

Hi {{first}},

You’ve been great to work with — thank you.

If a friend or neighbor needs [a dentist / a stylist / an HVAC or plumbing tech], we’d appreciate an introduction. They can call {{phone}} or book here: {{booking_url}}

No pressure and no forms to fill out — a text or forward of this email is enough.

— {{staff}}  
{{business}}

---

## Referral ask — shorter

**Subject:** A favor (only if it feels right)

Hi {{first}},

If anyone you trust needs {{business}}, feel free to send them our way: {{phone}} or {{booking_url}}

Thanks for being a customer.

— {{business}}

---

## After they refer someone (thank-you)

**Subject:** Thanks for the intro

Hi {{first}},

Thanks for sending [friend’s first name / “someone”] our way. We appreciate the trust.

— {{business}} · {{phone}}

---

## Optional SMS version (adapt)

Hi {{first}} — {{business}}. If a friend needs us, they can call {{phone}} or book: {{booking_url}} Thanks for thinking of us. Reply STOP to opt out.

---

## Notes

- Don’t invent rewards in these templates. If your business offers a referral credit, add one clear sentence and keep it compliant with your platform and local rules.  
- Log referrals in `tracker-template.csv` when a new customer actually books because of them.
