# SMS — Review ask (Day 0 + Day 3)

Paste into your phone, Google Voice, or SMS tool. Keep under ~2 short texts. Always include a way to opt out.

**Placeholders:** `{{business}}` · `{{first}}` · `{{review_link}}` · `{{phone}}` · `{{staff}}`

**Opt-out:** If they reply STOP / stop / unsubscribe / no — reply once confirming and don’t text again about reviews.

---

## Dental

### Day 0 — review ask
Hi {{first}} — {{business}} here. Glad we could help today. If we earned it, a quick Google review helps other patients find us: {{review_link}} Reply STOP to opt out.

### Day 3 — soft bump (only if no review / no reply)
{{first}} — friendly bump from {{business}}. No pressure — if you have 30 seconds, here’s our review link again: {{review_link}} Reply STOP to opt out.

### Optional — thank-you after they review
Thanks {{first}} — we saw your review. Means a lot to the team at {{business}}.

---

## Salon / beauty

### Day 0 — review ask
Hi {{first}} — {{business}}. Hope you love the look. If we earned a quick Google review, it helps a lot: {{review_link}} Reply STOP to opt out.

### Day 3 — soft bump
{{first}} — {{business}} here. Still would love a short review if you have a sec: {{review_link}} Totally fine either way. Reply STOP to opt out.

### Optional — thank-you after they review
{{first}} — thank you for the review! The team at {{business}} appreciated it.

---

## HVAC / plumbing / home services

### Day 0 — review ask
Hi {{first}} — {{business}}. Thanks for trusting us today. If the job went well, a Google review helps neighbors find us: {{review_link}} Reply STOP to opt out.

### Day 3 — soft bump
{{first}} — quick follow-up from {{business}}. If you’re happy with the work, here’s our review link: {{review_link}} Reply STOP to opt out.

### Optional — thank-you after they review
Thanks {{first}} — we saw your review. Glad we could help. — {{business}} · {{phone}}

---

## Notes

- Send Day 0 the same day as the visit when possible.  
- Day 3 is optional; skip if they already reviewed, booked again, or opted out.  
- Don’t stack Day 0 SMS + Day 0 email + in-person QR all at once unless they asked for the link.
