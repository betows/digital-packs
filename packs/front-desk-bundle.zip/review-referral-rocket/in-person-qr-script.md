# In-person QR script (~30 seconds)

Say this at checkout, the chair, or the truck wrap-up — only when the visit went well. Point them at a printed or phone QR that opens your Google review link.

**Prep:** Print a small card or sticker with your Google review QR + business name. Or open the QR on a spare tablet. Test the link on your own phone first.

---

## 30-second script (all verticals)

“{{first}}, thanks for coming in today — glad we could help.  
If we earned it, the easiest way to leave a quick Google review is right here — just open your camera and scan this.  
Takes about 30 seconds. Totally optional, and it helps other people find us.  
Appreciate you either way.”

Then **stop talking**. Let them scan or decline. Don’t hover or narrate while they type.

---

## If they say “I’ll do it later”

“No problem — I can text you the link so it’s on your phone.”  
→ Send SMS Day 0 from `sms-day0-day3.md`. Log `channel` = sms.

## If they say “I don’t do reviews”

“Totally fine — thanks for coming in.”  
→ Do **not** push. Mark notes in the tracker. No Day 3 bump.

## If they already left a review last time

“You’re the best — thank you again. We’re set.”  
→ Skip the ask. Optionally move to a referral ask later (see `email-referral-ask.md`).

---

## Vertical tweaks (optional one-liners)

- **Dental:** “…helps other patients who are looking for a dentist nearby.”  
- **Salon:** “…helps people looking for a stylist / colorist find us.”  
- **HVAC / plumbing:** “…helps neighbors who need a tech they can trust.”

---

## Do / don’t

| Do | Don’t |
|----|--------|
| Ask only after a good visit | Ask after a complaint or partial fix |
| One calm ask | Guilt (“we’ll lose the shop without reviews”) |
| Have the QR ready | Make them hunt for your Google page |
| Thank them once if they review | Offer cash for a five-star review |

**Time check:** under 30 seconds of talk + scan. If the line is backed up, text the link instead.
