# Missed-Call Recovery Pack — $29
SKU: `missed-call-recovery`  
SMS + email templates (Day 0 / Day 1 / Day 3) for leads who called and nobody answered, plus a simple log sheet.

**Who it’s for:** dental, salon, HVAC/plumbing, and other local service SMBs with a front desk or phone that rings after hours.  
**What it’s not:** a phone system, dialer, CRM, or SMS sender. You paste these into your own phone, Google Voice, TextMagic, Twilio, Gmail, etc.

Replace `{{business}}`, `{{first}}`, `{{phone}}`, `{{booking_url}}`, `{{hours}}` before sending.

---

## SOP (1 page) — How to run this pack

1. When a call is missed, log it the same day (see tracker columns below).
2. **Day 0 (within 15 minutes if possible, else same business day):** send SMS A for your vertical. If you have their email, also send Email Day 0.
3. **Day 1 (next morning, ~9–11am local):** if no reply/book, send SMS Day 1. Skip if they already booked or said stop.
4. **Day 3:** if still silent, send SMS Day 3 (break-up) OR Email Day 3 — pick one channel, don’t spam both.
5. Stop the sequence on any reply, booking, or “stop/unsubscribe”.
6. One missed-call = one contact. Don’t restart the sequence from Day 0 if they call again the same week — jump to a short “still need help?” SMS.
7. Use your real business number. Honor STOP on SMS same day. No fake urgency (“last slot ever”) unless it’s true.

**Speed rule:** the first text within 15 minutes beats a perfect template at Day 3.

---

## SMS — Dental

### Day 0
Hi {{first}} — this is {{business}}. Sorry we missed your call. Want us to hold a consult slot, or is it tooth pain / emergency? Reply here or call {{phone}}.

### Day 1
{{first}} — circling back from {{business}}. We still have openings this week. Prefer morning or afternoon? Or book here: {{booking_url}}

### Day 3
Last note from {{business}} about your missed call. Happy to help if you still need us — otherwise I’ll stop texting. {{phone}}

---

## SMS — Salon / beauty

### Day 0
Hi {{first}} — {{business}} here. We missed your call. Looking for cut, color, or a specific stylist? Reply and we’ll get you on the book. {{phone}}

### Day 1
{{first}} — still have midweek openings at {{business}}. Want a time, or book online: {{booking_url}}

### Day 3
Closing the loop on your call to {{business}}. Reply if you still want in; otherwise I won’t text again. {{phone}}

---

## SMS — HVAC / plumbing / home services

### Day 0
Hi {{first}} — {{business}}. Sorry we missed you. Is this a no-heat / leak emergency, or a quote? Reply 1 = emergency, 2 = quote, or call {{phone}}.

### Day 1
{{first}} — following up from {{business}}. We can usually put a tech on the calendar within {{hours}}. Still need help? Reply or call {{phone}}.

### Day 3
Last ping from {{business}} about your missed call. If the issue’s fixed, great — if not, we’re here: {{phone}}. I won’t keep texting.

---

## Email — all verticals (use with SMS or alone)

### Day 0
Subject: Sorry we missed your call — {{business}}

Hi {{first}},

You called {{business}} and we didn’t catch it. That’s on us.

Reply to this email with what you need (or the best number/time to reach you), or book here: {{booking_url}}

Same-day options are limited — earlier reply = better slot.

— {{business}}  
{{phone}}

### Day 1
Subject: Re: your call to {{business}}

{{first}} — quick bump in case my last note got buried.

Still happy to help. Prefer email, text, or a call back at {{phone}}?

Book online anytime: {{booking_url}}

— {{business}}

### Day 3
Subject: Closing the loop — {{business}}

Hi {{first}},

Last email from me about the missed call. If you still need {{business}}, reply or call {{phone}}. If not, no worries — I won’t follow up again.

— {{business}}

---

## Optional one-liners (after they reply “not now”)

- Totally fine — text us when you’re ready: {{phone}}
- Got it. Stopping texts. You can always book at {{booking_url}}
- Emergency later? Call {{phone}} — we triage same day when we can.

---

## Tracker columns (Sheets / Notion / CSV)

Paste as header row:

Missed_at | Contact | Phone | Email | Vertical (dental/salon/hvac) | Channel_used (SMS/email/both) | Status (Logged/Sent D0/Sent D1/Sent D3/Replied/Booked/Closed/Stop) | Last_sent | Next_bump | Notes

### Status meanings
- **Logged** — call missed, not contacted yet  
- **Sent D0 / D1 / D3** — sequence step done  
- **Replied** — stop sequence; handle as a human  
- **Booked** — win; note appointment time  
- **Stop** — they asked to stop; do not message again  

---

## Quick QA checklist before you go live
- [ ] Real business name + phone in every template  
- [ ] Booking URL works (or remove the link line)  
- [ ] STOP / opt-out honored same day  
- [ ] No invented “emergency fee” or fake scarcity  
- [ ] Front desk knows replies may land on the shared SMS inbox  

---

© Pack for buyer use. Edit freely for your brand voice.
