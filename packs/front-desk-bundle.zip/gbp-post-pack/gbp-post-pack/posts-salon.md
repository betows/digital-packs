# Salon posts (S1–S10)

S1 Offer: Midweek color openings — text us for tomorrow afternoon.
S2 Tip: Heat protectant before every blowout. Your ends will thank you in 90 days.
S3 Seasonal: Wedding season prep — trial run recommended 2 weeks before the day.
S4 Hiring: Looking for a stylist who loves consults. DM your IG portfolio.
S5 Offer: Blowout + style special Tue–Thu. Walk-ins welcome while slots last.
S6 Proof: Consult first, scissors second. We won’t talk you into a cut you didn’t ask for.
S7 Offer: Brow shaping add-on this week — ask when you book color.
S8 Tip: Silk pillowcase = less breakage. Cheap upgrade, real results.
S9 Community: {{city}} — tag us in your fresh cut. We repost favorites Fridays.
S10 Offer: Loyalty punch card at the desk. 10th visit = on us (ask for rules).
