# SOP — How to paste into Google Business Profile

1. Open Google Business Profile → Posts → Create post.
2. Pick today’s row from the 30-day calendar.
3. Paste text. Add 1 real photo from your shop (no stock required).
4. Button: Book / Call / Learn more → your real URL or phone.
5. Post 1× per day max. Skip Sundays if short-staffed.
6. Do **not** invent star ratings or fake customer names.
