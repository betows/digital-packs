# Google Business Profile Post Pack

**SKU:** gbp-post-pack  
**Price:** US$ 27  

30 ready-to-paste Google Business Profile posts (EN) for dental, salon, and HVAC/plumbing — plus a 30-day calendar and a one-page SOP.

## What's included
- `SOP.md` — how to paste into GBP
- `posts-dental.md` — D1–D10
- `posts-salon.md` — S1–S10
- `posts-hvac-plumbing.md` — H1–H10
- `calendar-30-day.md` — rotation map

## Not included
Ad accounts, boosting, or review generation.
