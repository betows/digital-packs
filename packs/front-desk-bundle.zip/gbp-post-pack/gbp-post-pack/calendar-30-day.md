# 30-day calendar (rotate verticals)

Day 1 D1 · 2 S1 · 3 H1 · 4 D2 · 5 S2 · 6 H2 · 7 D3 · 8 S3 · 9 H3 · 10 D4 · 11 S4 · 12 H4 · 13 D5 · 14 S5 · 15 H5 · 16 D6 · 17 S6 · 18 H6 · 19 D7 · 20 S7 · 21 H7 · 22 D8 · 23 S8 · 24 H8 · 25 D9 · 26 S9 · 27 H9 · 28 D10 · 29 S10 · 30 H10

Replace `{{city}}` before posting.
