# HVAC / Plumbing posts (H1–H10)

H1 Offer: Same-day diagnostic windows this week — call before noon.
H2 Tip: Change furnace filters every 90 days. $15 part, fewer emergency calls.
H3 Seasonal: Pre-winter tune-up — beat the first cold snap rush.
H4 Hiring: Hiring a licensed tech. Clean driving record + customer manners required.
H5 Offer: Water heater flush special this month — ask for the member rate.
H6 Proof: We show up in the window we quote. If we’re late, we text — no ghosting.
H7 Offer: Camera drain inspect before we recommend replacement. See the clog yourself.
H8 Tip: Know where your main shutoff is. 30 seconds that can save a ceiling.
H9 Community: {{city}} homeowners — storm damage? Call; we’ll triage honestly.
H10 Offer: Maintenance plan open for new members. Priority scheduling, no drama.
