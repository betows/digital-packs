"""Load and group invoice rows from CSV."""
from __future__ import annotations

import csv
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


REQUIRED_COLUMNS = {
    "invoice_number",
    "client_name",
    "date",
    "description",
    "qty",
    "unit_price",
}

OPTIONAL_COLUMNS = {
    "client_email",
    "client_address",
    "due_date",
    "tax_rate",
    "notes",
    "currency",
}


@dataclass
class LineItem:
    description: str
    qty: float
    unit_price: float
    tax_rate: float = 0.0

    @property
    def subtotal(self) -> float:
        return self.qty * self.unit_price

    @property
    def tax(self) -> float:
        return self.subtotal * (self.tax_rate / 100.0)

    @property
    def total(self) -> float:
        return self.subtotal + self.tax


@dataclass
class Invoice:
    invoice_number: str
    client_name: str
    date: str
    client_email: str = ""
    client_address: str = ""
    due_date: str = ""
    notes: str = ""
    currency: str = ""
    items: list[LineItem] = field(default_factory=list)

    @property
    def subtotal(self) -> float:
        return sum(i.subtotal for i in self.items)

    @property
    def tax_total(self) -> float:
        return sum(i.tax for i in self.items)

    @property
    def grand_total(self) -> float:
        return sum(i.total for i in self.items)


def _f(val: Any, default: float = 0.0) -> float:
    if val is None:
        return default
    s = str(val).strip().replace(",", "")
    if s == "":
        return default
    return float(s)


def load_invoices(csv_path: Path) -> list[Invoice]:
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")

    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            raise ValueError("CSV has no header row")
        headers = {h.strip().lower(): h for h in reader.fieldnames}
        missing = REQUIRED_COLUMNS - set(headers)
        if missing:
            raise ValueError(
                "CSV missing required columns: "
                + ", ".join(sorted(missing))
                + f". Found: {', '.join(reader.fieldnames)}"
            )

        def cell(row: dict, key: str, default: str = "") -> str:
            raw_key = headers.get(key)
            if raw_key is None:
                return default
            return (row.get(raw_key) or default).strip()

        grouped: OrderedDict[str, Invoice] = OrderedDict()
        for i, row in enumerate(reader, start=2):
            inv_no = cell(row, "invoice_number")
            if not inv_no:
                raise ValueError(f"Row {i}: invoice_number is empty")
            desc = cell(row, "description")
            if not desc:
                raise ValueError(f"Row {i}: description is empty")
            try:
                qty = _f(cell(row, "qty"), 0.0)
                price = _f(cell(row, "unit_price"), 0.0)
                tax = _f(cell(row, "tax_rate"), 0.0)
            except ValueError as exc:
                raise ValueError(f"Row {i}: bad number — {exc}") from exc

            item = LineItem(
                description=desc,
                qty=qty,
                unit_price=price,
                tax_rate=tax,
            )

            if inv_no not in grouped:
                grouped[inv_no] = Invoice(
                    invoice_number=inv_no,
                    client_name=cell(row, "client_name"),
                    client_email=cell(row, "client_email"),
                    client_address=cell(row, "client_address"),
                    date=cell(row, "date"),
                    due_date=cell(row, "due_date"),
                    notes=cell(row, "notes"),
                    currency=cell(row, "currency"),
                    items=[item],
                )
            else:
                grouped[inv_no].items.append(item)
                # Prefer first non-empty notes/due_date if later rows blank
                inv = grouped[inv_no]
                if not inv.notes and cell(row, "notes"):
                    inv.notes = cell(row, "notes")
                if not inv.due_date and cell(row, "due_date"):
                    inv.due_date = cell(row, "due_date")

    return list(grouped.values())
