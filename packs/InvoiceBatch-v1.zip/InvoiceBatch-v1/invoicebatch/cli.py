"""CLI entry for InvoiceBatch."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .csv_loader import load_invoices
from .pdf import load_company, render_invoice


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="invoicebatch",
        description=(
            "InvoiceBatch — turn a CSV of line items into branded invoice PDFs. "
            "One PDF per invoice_number. Multiple rows with the same number = line items."
        ),
    )
    p.add_argument(
        "--csv",
        required=True,
        type=Path,
        help="Path to invoices CSV (utf-8)",
    )
    p.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Path to company.json (seller details). Optional.",
    )
    p.add_argument(
        "--out",
        type=Path,
        default=Path("./invoices-out"),
        help="Output folder for PDFs (default: ./invoices-out)",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Parse + print plan without writing PDFs",
    )
    p.add_argument(
        "--prefix",
        default="invoice-",
        help="Filename prefix (default: invoice-)",
    )
    p.add_argument("--version", action="version", version=f"InvoiceBatch {__version__}")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        invoices = load_invoices(args.csv)
        company = load_company(args.config)
    except (FileNotFoundError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    if not invoices:
        print("No invoices found in CSV.", file=sys.stderr)
        return 1

    print(f"InvoiceBatch {__version__}")
    print(f"Company : {company['company_name']}")
    print(f"Invoices: {len(invoices)}")
    print(f"Output  : {args.out.resolve()}")
    print("-" * 48)

    written = 0
    for inv in invoices:
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in inv.invoice_number)
        out_file = Path(args.out) / f"{args.prefix}{safe}.pdf"
        print(
            f"  #{inv.invoice_number}  →  {inv.client_name}  "
            f"({len(inv.items)} lines, total {inv.grand_total:,.2f})"
            + ("  [dry-run]" if args.dry_run else f"  → {out_file.name}")
        )
        if not args.dry_run:
            render_invoice(inv, company, out_file)
            written += 1

    print("-" * 48)
    if args.dry_run:
        print(f"Dry-run OK. Would write {len(invoices)} PDF(s).")
    else:
        print(f"Done. Wrote {written} PDF(s) to {args.out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
