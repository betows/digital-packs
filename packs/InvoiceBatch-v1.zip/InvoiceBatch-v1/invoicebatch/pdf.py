"""Render a single Invoice to PDF via ReportLab."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from .csv_loader import Invoice


DEFAULT_COMPANY: dict[str, Any] = {
    "company_name": "Your Company LLC",
    "address": "123 Main St, Suite 100\nAustin, TX 78701",
    "email": "billing@yourcompany.com",
    "phone": "",
    "tax_id": "",
    "payment_terms": "Net 30 — Thank you for your business.",
    "currency_symbol": "$",
    "accent_color": "#1a56db",
    "footer": "Questions? Reply to this invoice email.",
}


def load_company(config_path: Path | None) -> dict[str, Any]:
    cfg = dict(DEFAULT_COMPANY)
    if config_path is None:
        return cfg
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Company config not found: {path}")
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError("company.json must be a JSON object")
    cfg.update({k: v for k, v in data.items() if v is not None})
    return cfg


def _money(symbol: str, amount: float) -> str:
    return f"{symbol}{amount:,.2f}"



def _nl(s: str) -> str:
    """Normalize newlines coming from JSON or CSV (real or escaped)."""
    return (s or "").replace("\\n", "\n").replace("\r\n", "\n").replace("\r", "\n")

def _hex(color: str) -> colors.Color:
    c = color.lstrip("#")
    if len(c) != 6:
        return colors.HexColor("#1a56db")
    return colors.HexColor("#" + c)


def render_invoice(
    invoice: Invoice,
    company: dict[str, Any],
    out_path: Path,
) -> Path:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    symbol = invoice.currency or company.get("currency_symbol", "$")
    accent = _hex(str(company.get("accent_color", "#1a56db")))

    doc = SimpleDocTemplate(
        str(out_path),
        pagesize=letter,
        leftMargin=0.7 * inch,
        rightMargin=0.7 * inch,
        topMargin=0.6 * inch,
        bottomMargin=0.6 * inch,
    )

    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "InvTitle",
        parent=styles["Heading1"],
        fontSize=22,
        textColor=accent,
        spaceAfter=4,
    )
    label = ParagraphStyle(
        "Label",
        parent=styles["Normal"],
        fontSize=9,
        textColor=colors.HexColor("#64748b"),
        spaceAfter=2,
    )
    body = ParagraphStyle(
        "Body",
        parent=styles["Normal"],
        fontSize=10,
        leading=14,
    )
    small = ParagraphStyle(
        "Small",
        parent=styles["Normal"],
        fontSize=8,
        textColor=colors.HexColor("#64748b"),
        alignment=TA_LEFT,
    )
    right = ParagraphStyle(
        "Right",
        parent=styles["Normal"],
        fontSize=10,
        alignment=TA_RIGHT,
    )

    story: list = []

    # Header
    company_block = [
        Paragraph(f"<b>{company['company_name']}</b>", body),
        Paragraph(_nl(company.get("address", "")).replace("\n", "<br/>"), body),
    ]
    if company.get("email"):
        company_block.append(Paragraph(company["email"], body))
    if company.get("phone"):
        company_block.append(Paragraph(company["phone"], body))
    if company.get("tax_id"):
        company_block.append(Paragraph(f"Tax ID: {company['tax_id']}", body))

    meta_lines = [
        Paragraph("INVOICE", title),
        Paragraph(f"<b>#{invoice.invoice_number}</b>", body),
        Spacer(1, 6),
        Paragraph("Date", label),
        Paragraph(invoice.date, body),
    ]
    if invoice.due_date:
        meta_lines += [Paragraph("Due", label), Paragraph(invoice.due_date, body)]

    header = Table(
        [[company_block, meta_lines]],
        colWidths=[4.2 * inch, 2.6 * inch],
    )
    header.setStyle(
        TableStyle(
            [
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ALIGN", (1, 0), (1, 0), "RIGHT"),
            ]
        )
    )
    story.append(header)
    story.append(Spacer(1, 18))

    # Bill to
    story.append(Paragraph("BILL TO", label))
    story.append(Paragraph(f"<b>{invoice.client_name}</b>", body))
    if invoice.client_address:
        story.append(
            Paragraph(_nl(invoice.client_address).replace("\n", "<br/>"), body)
        )
    if invoice.client_email:
        story.append(Paragraph(invoice.client_email, body))
    story.append(Spacer(1, 16))

    # Line items table
    data = [["Description", "Qty", "Unit price", "Tax %", "Amount"]]
    for item in invoice.items:
        data.append(
            [
                Paragraph(item.description, body),
                f"{item.qty:g}",
                _money(symbol, item.unit_price),
                f"{item.tax_rate:g}",
                _money(symbol, item.total),
            ]
        )

    table = Table(
        data,
        colWidths=[3.2 * inch, 0.7 * inch, 1.1 * inch, 0.7 * inch, 1.1 * inch],
        repeatRows=1,
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), accent),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 9),
                ("FONTSIZE", (0, 1), (-1, -1), 9),
                ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                ("ALIGN", (0, 0), (0, -1), "LEFT"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#e2e8f0")),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 14))

    # Totals
    totals = [
        ["Subtotal", _money(symbol, invoice.subtotal)],
        ["Tax", _money(symbol, invoice.tax_total)],
        ["TOTAL", _money(symbol, invoice.grand_total)],
    ]
    totals_table = Table(totals, colWidths=[5.4 * inch, 1.4 * inch])
    totals_table.setStyle(
        TableStyle(
            [
                ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
                ("FONTNAME", (0, 2), (-1, 2), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 1), 10),
                ("FONTSIZE", (0, 2), (-1, 2), 12),
                ("TEXTCOLOR", (0, 2), (-1, 2), accent),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ("LINEABOVE", (0, 2), (-1, 2), 1, accent),
            ]
        )
    )
    story.append(totals_table)

    if invoice.notes or company.get("payment_terms"):
        story.append(Spacer(1, 20))
        story.append(Paragraph("NOTES / PAYMENT", label))
        if company.get("payment_terms"):
            story.append(Paragraph(company["payment_terms"], body))
        if invoice.notes:
            story.append(Paragraph(_nl(invoice.notes).replace("\n", "<br/>"), body))

    if company.get("footer"):
        story.append(Spacer(1, 28))
        story.append(Paragraph(company["footer"], small))

    doc.build(story)
    return out_path
