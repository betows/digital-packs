"""InvoiceBatch — CSV → branded invoice PDFs."""
__version__ = "1.0.0"
