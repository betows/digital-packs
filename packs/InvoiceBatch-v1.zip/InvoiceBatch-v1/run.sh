#!/usr/bin/env bash
# Convenience launcher — uses local .venv if present, else system python3.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if [[ -x "$ROOT/.venv/bin/python" ]]; then
  exec "$ROOT/.venv/bin/python" -m invoicebatch "$@"
else
  exec python3 -m invoicebatch "$@"
fi
