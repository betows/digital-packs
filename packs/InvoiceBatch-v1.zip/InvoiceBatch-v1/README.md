# InvoiceBatch v1.0 — CSV → Invoice PDF Kit

**One command. Many invoices. Real PDFs.**

InvoiceBatch is a tiny Python CLI that reads a CSV of line items and writes branded invoice PDFs — one file per `invoice_number`. Multiple CSV rows with the same number become line items on the same invoice.

Works offline. No SaaS login. No subscription. Unzip → install one dependency → run.

---

## Requirements

- Python 3.10+ (3.11 / 3.12 / 3.13 fine)
- One package: `reportlab`

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

---

## 60-second quick start

```bash
# From the unzipped folder:
chmod +x run.sh
./run.sh --csv examples/sample-invoices.csv --config examples/company.json --out ./my-invoices
```

Open `my-invoices/invoice-INV-1001.pdf`. Edit `examples/company.json` to your brand. Replace the CSV with your clients. Re-run.

Dry-run (no files written):

```bash
./run.sh --csv examples/sample-invoices.csv --config examples/company.json --dry-run
```

Or without the shell helper:

```bash
python -m invoicebatch --csv examples/sample-invoices.csv --config examples/company.json --out ./my-invoices
```

---

## CSV columns

**Required**

| Column | Meaning |
|--------|---------|
| `invoice_number` | Groups rows into one PDF |
| `client_name` | Bill-to name |
| `date` | Invoice date (any string you like, e.g. `2026-09-28`) |
| `description` | Line item text |
| `qty` | Quantity (number) |
| `unit_price` | Unit price (number) |

**Optional**

| Column | Meaning |
|--------|---------|
| `client_email` | Bill-to email |
| `client_address` | Bill-to address (use real newlines in the cell) |
| `due_date` | Due date |
| `tax_rate` | Tax % for that line (e.g. `8.25`) |
| `notes` | Shown under payment terms |
| `currency` | Override symbol per invoice (`$`, `€`, `R$`…) |

See `examples/sample-invoices.csv`.

---

## Company config (`company.json`)

```json
{
  "company_name": "Your Company LLC",
  "address": "123 Main St\nCity, ST 00000",
  "email": "billing@you.com",
  "phone": "+1 (555) 000-0000",
  "tax_id": "EIN 00-0000000",
  "payment_terms": "Net 15. Pay via ACH or card.",
  "currency_symbol": "$",
  "accent_color": "#0f766e",
  "footer": "Questions? billing@you.com"
}
```

`accent_color` is the header bar + TOTAL color (hex).

---

## CLI flags

```
--csv PATH        Invoices CSV (required)
--config PATH     company.json (optional; uses defaults if omitted)
--out DIR         Output folder (default: ./invoices-out)
--dry-run         Parse + print plan, write nothing
--prefix TEXT     Filename prefix (default: invoice-)
--version
```

---

## What's in this zip

```
InvoiceBatch-v1/
  README.md
  LICENSE.txt
  requirements.txt
  run.sh
  invoicebatch/          # Python package
  examples/
    company.json
    sample-invoices.csv
    sample-pdfs/          # pre-rendered demo PDFs
```

---

## Support & refund

30-day email refund — reply to your purchase receipt or email the seller address on your order confirmation. No hoops.

---

## License

Personal + commercial use for the buyer (generate invoices for your clients). Redistribution / resale of this kit as a product is not allowed. See `LICENSE.txt`.
