# Landing Page Pack — $99
Copy + section map for a one-page service site (dental · salon · HVAC/plumbing).  
Hand this to any builder (Framer, Webflow, Carrd, Next, WordPress). **Not** a hosted site.

---

## SOP — How to use

1. Pick your vertical file section below (or remix).
2. Follow **Section order** top → bottom. Do not add a sixth hero.
3. Replace every `{{bracket}}` with your real city, phone, hours, URL.
4. Proof: use real reviews you own. Leave proof blocks short if you have fewer than 3.
5. CTA everywhere = Call / Book / Form — one primary action only.
6. Launch with 1 page. Blog later.

**Not included:** Hosted website, developer hours, photos, Google ads, or CRM.

---

## Universal section order (all verticals)

1. Hero (headline + sub + primary CTA)
2. Trust strip (years / city / license line — only if true)
3. Services (3–6 cards)
4. How it works (3 steps)
5. Proof (3 short quotes or “as seen in” — no fake stars)
6. Offer / urgency (optional, honest)
7. FAQ (5)
8. Final CTA + phone + service area

---

## A — Dental one-pager

**Hero H1:** Family dentistry in {{city}} that doesn’t rush you.  
**Sub:** Cleanings, exams, and same-week openings when we have them. Call or book online.  
**CTA:** Book a visit · Call {{phone}}

**Trust strip examples (only if true):** Serving {{city}} since {{year}} · {{language}} spoken · Evening hours {{days}}

**Services (pick 4–6):** Cleanings & exams · Fillings · Whitening consults · Crowns · Emergency tooth pain · Kids’ visits

**How it works:** 1) Book or call 2) We confirm and share what to bring 3) Visit — we explain before we start

**Proof placeholders:** “[Short real review]” — {{initials}} · “[Short real review]” — {{initials}}

**Offer (optional):** New patient exam + cleaning special — ask when you book. (Delete if you don’t run one.)

**FAQ:**
1. Do you take my insurance? — We work with many plans; call with yours and we’ll check.
2. Same-week openings? — Sometimes. Ask when you call.
3. First visit length? — Usually 45–75 minutes.
4. Parking? — {{parking_note}}
5. Emergency pain? — Call early; we hold limited same-day slots when we can.

**Final CTA:** Ready for a calmer visit? Call {{phone}} or book at {{url}}. Serving {{city}} and nearby.

---

## B — Salon one-pager

**Hero H1:** Color and cuts in {{city}} — consult first, scissors second.  
**Sub:** Book midweek openings. Walk-ins when the board allows.  
**CTA:** Book now · Text {{phone}}

**Services:** Cut & style · Color · Blowout · Bridal trial · Brows · Treatments

**How it works:** 1) Book the service 2) Short consult on goals and hair history 3) Service + home-care tips

**FAQ:**
1. How far ahead should I book color? — 1–2 weeks is safest; midweek is easier.
2. Cancellation? — {{cancel_policy}}
3. Kids? — {{kids_policy}}
4. Do you sell products? — {{products_note}}
5. Parking / transit? — {{access_note}}

**Final CTA:** Fresh cut this week? Book at {{url}} or text {{phone}}.

---

## C — HVAC / Plumbing one-pager

**Hero H1:** Fast, honest plumbing & HVAC in {{city}}.  
**Sub:** Same-day diagnostic windows when available. We text if we’re running late.  
**CTA:** Call {{phone}} · Request service

**Services:** Drain clearing · Water heaters · Leak repair · AC / furnace tune-up · Camera inspection · Maintenance plans

**How it works:** 1) Call or form — describe the issue 2) We give a window and show up in it 3) Options + price before major work

**FAQ:**
1. Service call fee? — {{fee_note}}
2. Emergency nights/weekends? — {{emergency_note}}
3. Licensed & insured? — {{license_note}}
4. Financing? — {{financing_note}}
5. Areas served? — {{city}} and {{nearby}}

**Final CTA:** Don’t wait on a leak or no-heat. Call {{phone}}. Serving {{city}}.

---

## Wireframe notes for the builder

- Mobile-first; CTA sticky optional on mobile.
- Hero image: real shop / truck / team — not generic stock if you can avoid it.
- One phone number sitewide.
- Footer: address, hours, license #, privacy link.

---

## License
Use for your own business sites. Don’t resell this pack unchanged as your own product.
