# Outbound Ops Kit — $49
Complete pack: sequences · subjects · snippets · tracker · SOP  
Replace `{{sales_page_url}}` with the live sales URL before shipping.

---

## SOP (1 page) — How to run this kit

1. Duplicate the Notion tracker (or paste the CSV columns below into Sheets/Notion).
2. Pick **one** sequence that matches the vertical (A service SMB / B ops angle / C general B2B).
3. Personalize **only** the first line of Day 0 (name, company, one real detail from their site).
4. Send Day 0 → wait 3 days → Day 3 if no reply → wait 4 days → Day 7 break-up.
5. Log every send/reply in the tracker. Stop the sequence on any reply.
6. This is **not** a sender. You use your own Gmail/Outlook. Respect CAN-SPAM: real From, physical address in signature if required, honor opt-outs same day.

**Who it’s for:** solo founders / SDRs doing outbound without Instantly.  
**What it’s not:** a sending tool, lead list, or Instantly clone.

---

## Sequence A — Service SMB (dental / salon / home services)

### Day 0
Subject: pick from list

Hi {{first}},

Saw {{company}} books online — curious how you handle same-day cancels and no-shows when the calendar looks full but the chair/truck is empty.

I put together a small outbound ops kit (sequences + tracker) for operators who still chase follow-ups by hand. Not a pitch for software — just the cadence docs.

If useful: {{sales_page_url}}

— {{your_name}}

### Day 3
{{first}} — bumping once. If no-shows aren’t a pain, ignore me. If they are, the kit is here: {{sales_page_url}}

### Day 7
Closing the loop. Won’t email again. Kit stays at {{sales_page_url}} if you want it later.

---

## Sequence B — Empty-calendar / ops angle

### Day 0
Hi {{first}},

Quick question: when someone cancels at 8am, does that slot get offered to a waitlist by 9 — or does it just die?

I packaged the Day 0/3/7 cadences + a Notion tracker we use for outbound (same discipline, different channel). $49 one-time: {{sales_page_url}}

### Day 3
Following up once on the ops kit — sequences + subjects + reply snippets + tracker. Link: {{sales_page_url}}

### Day 7
Last note from me. If timing’s bad, no worries — {{sales_page_url}}

---

## Sequence C — General B2B outbound

### Day 0
Hi {{first}},

If you’re still rewriting the same cold email every Monday, this might save you an hour: 3 sequences, 20 subject lines, reply snippets, Notion tracker. $49: {{sales_page_url}}

### Day 3
Bump — kit details above. Happy to answer one question if you’re comparing to building it yourself.

### Day 7
Breaking up. Link remains {{sales_page_url}} — no more emails from me on this.

---

## 20 subject lines

1. {{first}} — empty chair this week?
2. Quick cancel-recovery idea
3. Booked ≠ filled
4. Same-day cancel → what happens by 9am?
5. Not a pitch deck — 3 lines
6. Your Monday cold email (stolen structure)
7. Stop rewriting the same outbound
8. Day 0 / 3 / 7 already written
9. Notion tracker for who to bump
10. Subject lines that aren’t “Quick question”
11. One kit, no Instantly required
12. For solo outbound (no SDR bench)
13. Reply snippets for “not now”
14. {{company}} + follow-up cadence
15. Worth $49 or build it yourself?
16. Closing the loop Friday
17. Last bump on the ops kit
18. Templates only — you keep your voice
19. Outbound without another SaaS seat
20. {{first}}, ignoring is fine

---

## Reply snippets

**Not now:** Totally fair — I’ll stop. Kit stays at {{sales_page_url}} if useful later.

**Send info:** It’s a downloadable kit (3 sequences, 20 subjects, snippets, Notion tracker) — $49 one-time: {{sales_page_url}}

**Who is this?** {{your_name}} — I sell a small outbound ops kit (templates + tracker), not a sending tool. Happy to drop the link or stop emailing.

**Interested:** Here’s the page: {{sales_page_url}} — pay once, download the pack.

**Unsubscribe / angry:** Removed. Sorry for the noise — you won’t hear from me again.

---

## Notion tracker columns

| Company | Contact | Email | Sequence (A/B/C) | Status | Last sent | Next bump | Notes |
|---------|---------|-------|------------------|--------|-----------|-----------|-------|

**Status values:** Queued · Sent D0 · Sent D3 · Sent D7 · Replied · Closed · Opt-out

### CSV header (for Sheets import)
```
Company,Contact,Email,Sequence,Status,Last sent,Next bump,Notes
```

---

## License / use
Personal / commercial use of the templates OK. Do not resell the pack as your own product.
