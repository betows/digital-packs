# Local Ads Swipe Pack — $35
SKU: `ads-swipe-pack`  
20 Meta (Facebook/Instagram) ad swipes + 10 organic captions for dental, salon, and HVAC/plumbing — plus a 1-page SOP.

**Who it’s for:** local service owners or marketers who need copy that converts without a creative agency.  
**What it’s not:** an ad account, pixel setup, creative design service, or managed ads. You paste into Meta Ads Manager with your own images and billing.

Replace `{{business}}`, `{{city}}`, `{{phone}}`, `{{url}}`, `{{offer}}` before publishing.

---

## SOP (1 page) — How to paste into Meta Ads Manager

1. Open Meta Ads Manager → Create → Traffic or Leads (match your goal).
2. Pick **one** swipe below. Do not mash three hooks into one ad.
3. Primary text = the long block. Headline = the short line. Description optional.
4. Creative: 1 real photo of your shop, truck, chair, or team (no fake “5-star” overlays).
5. CTA button: Call Now / Book Now / Learn More → your real `{{phone}}` or `{{url}}`.
6. Start with **1 ad set / 1 ad**, $10–20/day, one city radius. Kill losers after 50–100 clicks if CTR or cost/lead is awful.
7. Do **not** invent reviews, prices you won’t honor, or “#1 in {{city}}” without proof.
8. Refresh creative every 2–3 weeks. Swap hook, keep the offer honest.

**Organic:** use the 10 captions on FB/IG feed the same week — same offer, no “Sponsored” confusion.

---

## Ads 1–7 — Dental

### Ad 1 — Empty chair
**Hook / primary:** Your chair sat empty for 45 minutes last week. Ads didn’t cause that — unclear booking did. Same-week openings at {{business}} in {{city}}.  
**Headline:** Same-week dental openings  
**CTA:** Book Now → {{url}}

### Ad 2 — Tooth pain
**Primary:** Tooth pain at 7am? We hold an emergency window most mornings. Call {{phone}} — {{business}}, {{city}}.  
**Headline:** Dental emergency window  
**CTA:** Call Now

### Ad 3 — New patient calm
**Primary:** First visit shouldn’t feel like a surprise bill. We explain the plan before we start. New patient openings this week — {{business}}.  
**Headline:** New patient? Start here  
**CTA:** Learn More → {{url}}

### Ad 4 — Cleaning offer
**Primary:** {{offer}} — cleaning slots open before they fill. Book online or call {{phone}}.  
**Headline:** Cleaning openings this week  
**CTA:** Book Now

### Ad 5 — Kids / back-to-school
**Primary:** Back-to-school checkups without the Saturday circus. Grab a weekday slot for the kids at {{business}}.  
**Headline:** Kids’ checkup slots  
**CTA:** Book Now

### Ad 6 — Whitening consult
**Primary:** Curious about whitening? Start with a consult — no pressure pitch. Ask the front desk at {{business}}.  
**Headline:** Whitening consult  
**CTA:** Learn More

### Ad 7 — Refer a friend
**Primary:** Like us? Refer a friend — both get a thank-you perk. Ask how at {{phone}}.  
**Headline:** Refer & thank-you perk  
**CTA:** Call Now

---

## Ads 8–14 — Salon

### Ad 8 — Midweek color
**Primary:** Midweek color openings — less rush, better consult. Text or book {{business}} in {{city}}.  
**Headline:** Midweek color openings  
**CTA:** Book Now → {{url}}

### Ad 9 — Consult first
**Primary:** Consult first, scissors second. We won’t talk you into a cut you didn’t ask for.  
**Headline:** Consult before the cut  
**CTA:** Book Now

### Ad 10 — Blowout special
**Primary:** {{offer}} blowout + style Tue–Thu while slots last. Walk-ins welcome when the board is open.  
**Headline:** Tue–Thu blowout special  
**CTA:** Call Now → {{phone}}

### Ad 11 — Wedding trial
**Primary:** Wedding in 2+ weeks? Book the trial now — day-of goes smoother. {{business}}.  
**Headline:** Wedding hair trial  
**CTA:** Book Now

### Ad 12 — Brow add-on
**Primary:** Color booked? Ask for brow shaping add-on this week.  
**Headline:** Brow add-on this week  
**CTA:** Learn More

### Ad 13 — Hiring stylist
**Primary:** Hiring a stylist who loves consults. Portfolio + good manners required. DM or apply via {{url}}.  
**Headline:** Stylist wanted  
**CTA:** Learn More

### Ad 14 — Loyalty card
**Primary:** Punch card at the desk — 10th visit rules posted in-shop. Ask us.  
**Headline:** Loyalty punch card  
**CTA:** Call Now

---

## Ads 15–20 — HVAC / Plumbing

### Ad 15 — Same-day diagnostic
**Primary:** Same-day diagnostic windows this week — call before noon. {{business}}, {{city}}.  
**Headline:** Same-day diagnostic  
**CTA:** Call Now → {{phone}}

### Ad 16 — Filter tip → offer
**Primary:** $15 filter every 90 days beats a weekend emergency. Need a tune-up anyway? We’re booking {{city}} this week.  
**Headline:** Filter tip + tune-up  
**CTA:** Book Now → {{url}}

### Ad 17 — Pre-winter
**Primary:** Pre-winter tune-up before the first cold snap rush. Honest triage — we won’t sell what you don’t need.  
**Headline:** Pre-winter tune-up  
**CTA:** Call Now

### Ad 18 — Show up window
**Primary:** We show up in the window we quote. If we’re late, we text — no ghosting.  
**Headline:** On-time service window  
**CTA:** Learn More

### Ad 19 — Camera drain
**Primary:** Camera drain inspect before we recommend replacement. See the clog yourself.  
**Headline:** See the clog yourself  
**CTA:** Book Now

### Ad 20 — Maintenance plan
**Primary:** Maintenance plan open for new members — priority scheduling, less drama. Ask {{phone}}.  
**Headline:** Priority maintenance plan  
**CTA:** Call Now

---

## Organic captions (10) — feed / Stories text

1. Same-week openings at {{business}} — link in bio or call {{phone}}.
2. Missed us on the phone? Text this number — we’ll get you on the board.
3. Real talk: we explain price before we start. {{city}} knows.
4. Midweek is the secret — fewer crowds, better consults.
5. Filter change reminder from your friends at {{business}}.
6. Hiring: good with people > fancy résumé. Details on site.
7. Storm / emergency? Call early — we triage honest.
8. Fresh cut / fresh smile Friday — tag us, we may repost.
9. {{offer}} ends when the calendar fills. Not fake scarcity.
10. New here? Start with the FAQ on {{url}} — then book.

---

## Quick checklist before you spend $1
- [ ] Real phone & URL in the ad
- [ ] Offer you can actually deliver this week
- [ ] One vertical per campaign
- [ ] No fake reviews or “guaranteed #1”
- [ ] Opt-out / privacy policy linked if running Lead Ads

