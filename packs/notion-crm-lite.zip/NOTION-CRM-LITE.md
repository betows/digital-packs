# Notion CRM Lite — $39
A small pipeline for operators who hate CRMs.  
Lead → Booked → Showed → Paid. Nothing else.

Replace `{{sales_page_url}}` only if you resell or link out. Buyers use this file + the CSV to rebuild in Notion in ~15 minutes.

---

## SOP (1 page) — Build it in Notion

1. Create a new Notion page: **Pipeline**.
2. Add a **Database — Full page** named `Leads`.
3. Create properties exactly as in **Schema** below (names matter).
4. Add four filtered views (or board groups by Status): Lead · Booked · Showed · Paid.
5. Optional: import `leads-template.csv` (headers only + 3 example rows — delete examples before real use).
6. Rule: every inbound (call, form, walk-in) becomes one row the same day. No second spreadsheet.
7. Move Status forward only when true (don’t mark Paid on a deposit unless that’s your rule — pick one and stick to it).
8. Weekly (10 min): open Lead view — anything >7 days with no Next action → call or close as Lost (add Lost only if you need it; default kit stays at 4 statuses).

**Who it’s for:** dental / salon / HVAC-plumbing owners (~5–50 staff) drowning in texts and sticky notes.  
**What it’s not:** hosted CRM software, automations, SMS sender, or reporting suite.

---

## Schema — `Leads` database

| Property | Type | Notes |
|----------|------|-------|
| Name | Title | Person or business |
| Status | Select | Lead · Booked · Showed · Paid |
| Vertical | Select | Dental · Salon · HVAC/Plumbing · Other |
| Phone | Phone | |
| Email | Email | |
| Source | Select | Call · Walk-in · Google · Referral · Other |
| Next action | Text | One concrete next step |
| Next date | Date | When to do Next action |
| Value ($) | Number | Expected or closed $ |
| Notes | Text | Short only |

### Status definitions
- **Lead** — Hand raised. Not on the calendar yet.
- **Booked** — Appointment on the books.
- **Showed** — They showed up (or job started).
- **Paid** — Money collected (or invoice settled). Done.

Keep Lost out of the default kit. If you need it later, add Select option **Lost** and a fifth view — don’t complicate day one.

---

## Board / views to create

1. **Board by Status** — default daily view.
2. **This week** — filter Next date is within 7 days.
3. **Needs phone** — Status = Lead AND Phone is not empty.
4. **Paid (30d)** — Status = Paid (sort Value desc) for a quick win list.

---

## Weekly review checklist (print / pin)

- [ ] Every new lead from this week has a row
- [ ] Every Lead has Next action + Next date
- [ ] Booked without Showed after appointment date → follow up or mark Lost
- [ ] Showed without Paid → send invoice / collect
- [ ] No row older than 14 days stuck on Lead without a decision

---

## Example rows (delete after import)

| Name | Status | Vertical | Phone | Email | Source | Next action | Next date | Value ($) | Notes |
|------|--------|----------|-------|-------|--------|-------------|-----------|-----------|-------|
| Alex Rivera | Lead | Dental | | | Google | Call back re: cleaning | | 180 | Morning inquiry |
| Jordan Lee | Booked | Salon | | | Referral | Confirm appt SMS | | 90 | Sat color |
| Sam Okonkwo | Showed | HVAC/Plumbing | | | Call | Collect card on site | | 450 | Drain clear |

---

## CSV header (Sheets → Notion import)

```
Name,Status,Vertical,Phone,Email,Source,Next action,Next date,Value ($),Notes
Alex Rivera,Lead,Dental,,,Google,Call back re: cleaning,,180,Morning inquiry
Jordan Lee,Booked,Salon,,,Referral,Confirm appt SMS,,90,Sat color
Sam Okonkwo,Showed,HVAC/Plumbing,,,Call,Collect card on site,,450,Drain clear
```

---

## License / use
Personal and commercial use of this schema OK. Do not resell the pack as your own product without change.
